#!/usr/bin/env python3
"""Export development-only unified248 plot tables; no fits or external reads."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import shutil

import numpy as np
import pandas as pd
from sklearn.metrics import (average_precision_score, precision_recall_curve,
                             roc_auc_score, roc_curve)


def downsample(x, y, threshold, maximum=5000):
    indices = np.unique(np.rint(np.linspace(0, len(x)-1, min(maximum,len(x)))).astype(int))
    return pd.DataFrame({'x':x[indices], 'y':y[indices],
                         'threshold':threshold[indices]})


def as_json(value):
    if isinstance(value, dict):
        return {str(k):as_json(v) for k,v in value.items()}
    if isinstance(value, list):
        return [as_json(v) for v in value]
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating,float)):
        return float(value) if np.isfinite(value) else None
    if isinstance(value, np.bool_):
        return bool(value)
    return value


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--model-dir',required=True,type=Path)
    ap.add_argument('--out',required=True,type=Path)
    args=ap.parse_args()
    root=args.model_dir
    if not (root/'MODEL_COMPLETE').exists():
        raise RuntimeError('unified model is not complete; keep stable training running')
    lock=json.loads((root/'CANDIDATE_LOCK.json').read_text())
    if not lock.get('one_model_and_one_cutoff_across_all_lengths') or not lock.get('previous_fresh_test_and_external_not_read'):
        raise RuntimeError('unified development-only lock contract differs')
    if len(lock['features']) != 248:
        raise RuntimeError('expected unified248 candidate')
    out=args.out
    data=out/'data'
    data.mkdir(parents=True,exist_ok=True)
    d=pd.read_parquet(root/'DEV_OOF_PREDICTIONS.parquet',columns=[
        'host_protein_id','connected_group','fold','length_kb','placement','y',
        'baseline_call','score','cohort_weight','per_length_eval_weight'])
    if not np.isfinite(d.score).all() or d.groupby('connected_group').fold.nunique().max()!=1:
        raise RuntimeError('incomplete or ungrouped development OOF predictions')
    cutoff=float(lock['threshold'])
    curves=[]
    points=[]
    metrics=[]
    for length in (0,20):
        g=d.loc[d.length_kb.eq(length)]
        y=g.y.to_numpy(bool)
        score=g.score.to_numpy(float)
        w=g.per_length_eval_weight.to_numpy(float)
        scope='FULL_REPLICON' if length==0 else '20kb'
        fpr,tpr,threshold=roc_curve(y,score,sample_weight=w,drop_intermediate=True)
        roc=downsample(fpr,tpr,threshold)
        roc['curve']='ROC';roc['scope']=scope;curves.append(roc)
        precision,recall,threshold=precision_recall_curve(y,score,sample_weight=w)
        pr=downsample(recall,precision,np.r_[threshold,np.nan])
        pr['curve']='PR';pr['scope']=scope;curves.append(pr)
        for method,pred in [('Unified248_locked',score>=cutoff),
                            ('Fixed_5kb',g.baseline_call.to_numpy(bool))]:
            inside=float(np.average(pred[y],weights=w[y]))
            outside=float(np.average(pred[~y],weights=w[~y]))
            p=float(np.average(y[pred],weights=w[pred])) if pred.any() else np.nan
            points.extend([{'scope':scope,'curve':'ROC','method':method,'x':outside,'y':inside},
                           {'scope':scope,'curve':'PR','method':method,'x':inside,'y':p}])
        metrics.append({'scope':scope,'windows':len(g),'unique_cargo':g.host_protein_id.nunique(),
                        'inside_windows':int(y.sum()),'outside_windows':int((~y).sum()),
                        'inside_cargo':g.loc[y,'host_protein_id'].nunique(),
                        'outside_cargo':g.loc[~y,'host_protein_id'].nunique(),
                        'auroc':roc_auc_score(y,score,sample_weight=w),
                        'auprc':average_precision_score(y,score,sample_weight=w),
                        'reference_inside_prevalence':np.average(y,weights=w),
                        'threshold':cutoff})
    pd.concat(curves,ignore_index=True).replace([np.inf,-np.inf],np.nan).to_csv(data/'ROC_PR_CURVES.tsv',sep='\t',index=False)
    pd.DataFrame(points).to_csv(data/'ROC_PR_POINTS.tsv',sep='\t',index=False)
    pd.DataFrame(metrics).to_csv(data/'ROC_PR_METRICS.tsv',sep='\t',index=False)
    for name in ('DEV_BY_SCOPE.tsv','FEATURE_IMPORTANCE.tsv','COHORT_BY_LENGTH.tsv'):
        if (root/name).exists():
            shutil.copy2(root/name,data/name)
    importance=pd.read_csv(data/'FEATURE_IMPORTANCE.tsv',sep='\t')
    importance['gain_percent']=100*importance.gain/importance.gain.sum()
    importance.to_csv(data/'FEATURE_IMPORTANCE.tsv',sep='\t',index=False)
    for name in ('CANDIDATE_LOCK.json','DEV_AUDIT.json','WEIGHT_AUDIT.json','TRAIN_PROTOCOL.json'):
        shutil.copy2(root/name,data/name)
    scopes=pd.read_csv(data/'DEV_BY_SCOPE.tsv',sep='\t').set_index('scope')
    def pct(value):return f'{100*value:.2f}%'
    def sentence(scope):
        row=scopes.loc[scope]
        label='完整来源复制子' if scope=='FULL_REPLICON' else '20 kb 片段'
        return (f'{label}：统一模型参考区内找回率为 {pct(row.model_inside_recall)}，'
                f'固定5 kb规则为 {pct(row.baseline_inside_recall)}；'
                f'参考区外报警率分别为 {pct(row.model_outside_alert)} 和 {pct(row.baseline_outside_alert)}。')
    explanations=[
      {'figure':'U01','title':'同一统一模型：完整序列与20 kb的ROC／PR',
       'paragraphs':[
        '这张图用同一个248特征模型设计、相同分组五折和同一个判阳性门槛，分别检查完整来源复制子和20 kb片段。每个验证折都由其余四折训练，完整与片段共享那一折模型。图中不是原236版和44版各取一张。',
        '上排ROC横轴是参考区外报警率，越靠左越少；纵轴是参考区内找回率，越高越多。下排PR横轴是找回率，纵轴是在报阳性基因中有多少处于参考ICE/IME区间。蓝线来自模型连续分数；蓝圆点是锁定门槛，橙菱形是固定5 kb规则。',
        sentence('FULL_REPLICON'),sentence('20kb'),
        '20 kb参考区外背景在训练设计中只按1/16抽样，评价用逆抽样权重16，并让同一基因的保留摆放位置等权。PR的参考区内占比使用校正后的权重，不能直接用窗口数相除。ROC面积和AP使用全部原始分数计算；曲线为显示抽稀，最多每条5000个点。',
        '这些都是开发集折外结果。共同门槛也由开发集折外结果选定，因此图中门槛点不属于独立外部验证。AUROC、AP和找回率均不是实测转移准确率。参考区外是未验证背景，不能全部称为真实不可移动阴性。']},
      {'figure':'U02','title':'同一模型、同一门槛：不同可见长度的表现',
       'paragraphs':[
        '横轴依次为2、5、10、20、50、100 kb精确长度片段，最右边单独列出完整来源复制子。两幅图都只用统一248模型和同一个门槛，蓝色为模型，橙色为5 kb规则。没有为不同长度各训练一个模型或另选门槛。',
        '左图是参考区内找回率，越高越多；右图是参考区外报警率，越低越少。两者要同时看：多找回若伴随更多区外报警，是一种取舍，不能只凭左图判断所有指标都更好。',
        '门槛是按“完整与片段的预设混合总体”匹配5 kb规则的区外报警预算，而不是对每个长度分别匹配。因此同一长度处两种方法的报警率可以不同。',
        '只有完整可见的ARG/MRG进入关联评价；片段中的MGE也必须整条CDS可见。一个基因最多有偏左、居中、偏右三种摆放，它们不是三个独立基因。各长度可保留的完整基因数不同；该图不把cargo被切断造成的损失算作关联模型漏报。',
        '这轮图展示参与混合训练设计的六个片段长度及完整来源序列，还不是统一模型1–100 kb每1 kb的全曲线，也不是新的独立测试。完整复制子与短片段的特征按各自可见范围计算。']},
      {'figure':'U03','title':'统一模型主要使用了哪些特征',
       'paragraphs':[
        '图中列出最终全开发集拟合模型增益最高的15个输入。横轴是该特征分裂增益占全部248项特征总增益的百分比，未重新按前15项归一化。',
        '较长的条形说明训练树在使用这个特征分裂时获得了更多目标函数改进。高度相关的特征可能互相分摊增益，数值并不等于生物学贡献百分比、因果作用或真实转移概率。',
        '这个统一模型同时拥有可见DNA组成与背景、邻居结构和功能、oriT，以及cargo和MGE的多尺度空间证据。它在完整与片段场景使用相同的248列顺序；片段行的上下文、邻居、oriT和MGE空间信息来自可见范围。',
        'V3HN蛋白类别和分数仍复用完整来源序列上已经完成的冻结注释；没有对每条破碎原始DNA从头重跑注释。因此应表述为冻结蛋白注释条件下的统一关联模型，而不是已经完成破碎DNA端到端准确率验证。']},
    ]
    (out/'逐图中文解释.json').write_text(json.dumps(explanations,ensure_ascii=False,indent=2)+'\n')
    audit={'model':'UNIFIED248','only_development_OOF':True,'external_data_read':False,
           'one_model_specification_all_scopes':True,'one_cutoff':cutoff,
           'ROC_PR_scope_weights':'per_length_eval_weight; placement-equal; outsideIPW16',
           'curve_display_max_points':5000,'curve_areas_computed_before_display_thinning':True,
           'rows_read':len(d),'feature_count':248,'models_fitted':0,'GPU_used':False,
           'metrics':metrics,'expected_figures':['U01','U02','U03']}
    (data/'EXPORT_AUDIT.json').write_text(json.dumps(as_json(audit),ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(as_json(audit),ensure_ascii=False),flush=True)


if __name__=='__main__':main()
